
import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, Loader2, Sparkles, ChevronRight } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

const QUICK_ENQUIRIES = [
  "Membership prices?",
  "Gym opening hours?",
  "Personal training?",
  "Workout for beginners?",
  "Subscription renewal?"
];

const AIChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'bot'; text: string; isStreaming?: boolean }[]>([
    { role: 'bot', text: 'Welcome to AZ Fitness! I am your AI performance assistant. How can I help you crush your goals today?' }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages]);

  const handleSend = async (forcedText?: string) => {
    const messageText = forcedText || input.trim();
    if (!messageText || isLoading) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: messageText }]);
    setIsLoading(true);

    // Prepare for streaming
    setMessages(prev => [...prev, { role: 'bot', text: '', isStreaming: true }]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const streamResponse = await ai.models.generateContentStream({
        model: 'gemini-3-flash-preview',
        contents: messageText,
        config: {
          systemInstruction: `You are AZ Fitness AI, the ultimate gym management and fitness assistant.
          AZ Fitness Details:
          - Opening Hours: 24/7 for Pro members, 5 AM - 11 PM for Standard members.
          - Membership Plans: Monthly ($49), Quarterly ($129), Yearly ($399).
          - Facilities: Olympic Lifting Platform, Sauna, Juice Bar, Cardio Zone.
          - Tone: Energetic, professional, concise, and motivating. 
          - Goal: Handle enquiries about the gym and provide fitness/nutrition advice.`,
        },
      });

      let fullText = '';
      for await (const chunk of streamResponse) {
        const textChunk = chunk.text;
        if (textChunk) {
          fullText += textChunk;
          setMessages(prev => {
            const newMessages = [...prev];
            const lastMsg = newMessages[newMessages.length - 1];
            if (lastMsg && lastMsg.role === 'bot') {
              lastMsg.text = fullText;
            }
            return newMessages;
          });
        }
      }
      
      // Mark streaming as complete
      setMessages(prev => {
        const newMessages = [...prev];
        const lastMsg = newMessages[newMessages.length - 1];
        if (lastMsg) lastMsg.isStreaming = false;
        return newMessages;
      });

    } catch (error) {
      console.error('AI Error:', error);
      setMessages(prev => {
        const filtered = prev.filter(m => !m.isStreaming || m.text !== '');
        return [...filtered, { role: 'bot', text: "I'm having trouble connecting to the AZ Fitness servers. Please try again in a moment." }];
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-20 right-6 md:bottom-8 md:right-8 z-[100]">
      {isOpen ? (
        <div className="bg-[#1A1A1A] w-[340px] sm:w-[400px] h-[550px] rounded-[2rem] border border-[#333] shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex flex-col overflow-hidden animate-in fade-in zoom-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="bg-[#222] p-5 flex items-center justify-between border-b border-[#333]">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#CCFF00] rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(204,255,0,0.3)]">
                <Bot size={22} color="#000" />
              </div>
              <div>
                <span className="font-black text-sm uppercase italic tracking-tighter block leading-none">AZ <span className="text-[#CCFF00]">AI</span></span>
                <span className="text-[10px] text-green-500 font-bold uppercase tracking-widest flex items-center mt-1">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1.5 animate-pulse"></span>
                  Online Assistant
                </span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-all">
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-5 custom-scrollbar bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
                <div className={`max-w-[88%] p-4 rounded-2xl text-sm leading-relaxed ${
                  m.role === 'user' 
                    ? 'bg-[#CCFF00] text-black font-bold rounded-tr-none shadow-lg' 
                    : 'bg-[#252525] text-gray-100 border border-[#333] rounded-tl-none'
                }`}>
                  {m.text || (m.isStreaming && <span className="inline-block w-2 h-4 bg-[#CCFF00] animate-pulse"></span>)}
                </div>
              </div>
            ))}
            
            {/* Quick Enquiry Chips */}
            {!isLoading && messages.length < 4 && (
              <div className="pt-2 flex flex-wrap gap-2 animate-in fade-in duration-500">
                {QUICK_ENQUIRIES.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSend(q)}
                    className="bg-[#222] hover:bg-[#333] border border-[#333] px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest text-[#CCFF00] transition-all hover:scale-105 active:scale-95 flex items-center group"
                  >
                    {q}
                    <ChevronRight size={10} className="ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-5 border-t border-[#333] bg-[#222]">
            <div className="relative group">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                <Sparkles size={16} className="text-gray-600 group-focus-within:text-[#CCFF00] transition-colors" />
              </div>
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask AZ Fitness AI..."
                className="w-full bg-[#1A1A1A] border border-[#333] rounded-2xl pl-11 pr-14 py-4 text-sm text-white focus:border-[#CCFF00] focus:ring-1 focus:ring-[#CCFF00]/30 outline-none transition-all placeholder:text-gray-600"
              />
              <button 
                onClick={() => handleSend()}
                disabled={isLoading || !input.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-[#CCFF00] rounded-xl flex items-center justify-center text-black hover:scale-105 active:scale-95 transition-all disabled:opacity-30 disabled:grayscale disabled:scale-100 shadow-lg"
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
              </button>
            </div>
            <p className="text-[9px] text-gray-600 text-center mt-3 uppercase font-black tracking-[0.2em]">Powered by AZ Fitness Intelligence</p>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-[#CCFF00] rounded-[1.5rem] flex items-center justify-center shadow-[0_15px_40px_rgba(204,255,0,0.4)] hover:scale-110 active:scale-90 transition-all text-black hover:rotate-3 relative group"
        >
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-[#121212] group-hover:animate-ping"></div>
          < MessageSquare size={30} className="group-hover:scale-110 transition-transform" />
        </button>
      )}
    </div>
  );
};

export default AIChatbot;
