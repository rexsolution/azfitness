
import React from 'react';
import { 
  LayoutDashboard, 
  Dumbbell, 
  CreditCard, 
  Settings, 
  LogOut, 
  ChevronRight,
  ShieldCheck,
  Menu,
  X
} from 'lucide-react';
import { Page, UserProfile } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  user: UserProfile;
  logout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentPage, setCurrentPage, user, logout }) => {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'workouts', label: 'Workouts', icon: Dumbbell },
    { id: 'subscription', label: 'Membership', icon: CreditCard },
    ...(user.role === 'admin' ? [{ id: 'admin', label: 'Admin Panel', icon: ShieldCheck }] : []),
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="flex min-h-screen bg-[#121212] text-[#E5E5E5] overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className={`
        hidden md:flex flex-col w-64 bg-[#1E1E1E] border-r border-[#333] transition-all duration-300
      `}>
        <div className="p-6 flex items-center space-x-3">
          <div className="w-10 h-10 bg-[#CCFF00] rounded-lg flex items-center justify-center">
            <Dumbbell size={24} color="#000" />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-white uppercase italic">AZ <span className="text-[#CCFF00]">Fitness</span></span>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id as Page)}
              className={`
                w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all
                ${currentPage === item.id 
                  ? 'bg-[#CCFF00] text-black font-bold shadow-[0_0_20px_rgba(204,255,0,0.2)]' 
                  : 'text-gray-400 hover:text-white hover:bg-[#252525]'}
              `}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
              {currentPage === item.id && <ChevronRight size={16} className="ml-auto" />}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-[#333]">
          <div className="flex items-center space-x-3 p-3 mb-4 rounded-xl bg-[#252525]">
            <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover" />
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold text-white truncate">{user.name}</p>
              <p className="text-xs text-gray-500 truncate capitalize">{user.role}</p>
            </div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 py-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
          >
            <LogOut size={18} />
            <span className="text-sm font-medium">Log out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Nav Top Bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-[#1E1E1E] border-b border-[#333] flex items-center justify-between px-6 z-50">
         <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-[#CCFF00] rounded flex items-center justify-center">
            <Dumbbell size={18} color="#000" />
          </div>
          <span className="text-lg font-extrabold tracking-tight text-white uppercase italic">AZ <span className="text-[#CCFF00]">Fitness</span></span>
        </div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-[#CCFF00]">
          {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {isSidebarOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="fixed inset-0 bg-black/80" onClick={() => setIsSidebarOpen(false)}></div>
          <div className="relative w-72 bg-[#1E1E1E] h-full shadow-xl flex flex-col p-6 space-y-8 animate-in slide-in-from-left duration-300">
             <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-[#CCFF00] rounded-lg flex items-center justify-center">
                <Dumbbell size={24} color="#000" />
              </div>
              <span className="text-xl font-extrabold tracking-tight text-white uppercase italic">AZ <span className="text-[#CCFF00]">Fitness</span></span>
            </div>
            <nav className="flex-1 space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id as Page);
                    setIsSidebarOpen(false);
                  }}
                  className={`
                    w-full flex items-center space-x-4 px-4 py-4 rounded-xl text-lg font-semibold
                    ${currentPage === item.id 
                      ? 'bg-[#CCFF00] text-black' 
                      : 'text-gray-400 hover:text-white'}
                  `}
                >
                  <item.icon size={24} />
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>
            <button 
              onClick={logout}
              className="flex items-center space-x-4 px-4 py-4 text-red-400 font-semibold"
            >
              <LogOut size={24} />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pt-20 pb-24 md:pt-0 md:pb-0 relative">
        <div className="container mx-auto px-6 py-8">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Tab Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#1E1E1E]/95 backdrop-blur-md border-t border-[#333] flex items-center justify-around px-2 z-50">
        {navItems.slice(0, 4).map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentPage(item.id as Page)}
            className={`
              flex flex-col items-center justify-center w-full h-full space-y-1
              ${currentPage === item.id ? 'text-[#CCFF00]' : 'text-gray-500'}
            `}
          >
            <item.icon size={20} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default Layout;
