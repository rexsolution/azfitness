
import React from 'react';

interface HeatmapProps {
  data: Date[];
}

const Heatmap: React.FC<HeatmapProps> = ({ data }) => {
  // Generate last 100 days
  const today = new Date();
  const days = Array.from({ length: 98 }, (_, i) => {
    const d = new Date();
    d.setDate(today.getDate() - (97 - i));
    return d;
  });

  const isActive = (date: Date) => {
    return data.some(d => d.toDateString() === date.toDateString());
  };

  return (
    <div className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333]">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-white italic uppercase tracking-wider">Consistency Heatmap</h3>
        <div className="flex items-center space-x-2 text-xs text-gray-400">
          <span>Less</span>
          <div className="flex space-x-1">
            <div className="w-3 h-3 bg-[#252525] rounded-sm border border-[#333]"></div>
            <div className="w-3 h-3 bg-[#CCFF00]/40 rounded-sm"></div>
            <div className="w-3 h-3 bg-[#CCFF00]/70 rounded-sm"></div>
            <div className="w-3 h-3 bg-[#CCFF00] rounded-sm"></div>
          </div>
          <span>More</span>
        </div>
      </div>
      
      <div className="grid grid-cols-14 gap-1.5 md:gap-2">
        {days.map((day, idx) => (
          <div
            key={idx}
            title={day.toDateString()}
            className={`
              aspect-square w-full rounded-sm transition-all
              ${isActive(day) ? 'bg-[#CCFF00] shadow-[0_0_8px_rgba(204,255,0,0.3)]' : 'bg-[#252525] hover:bg-[#333]'}
            `}
          />
        ))}
      </div>
      
      <div className="mt-6 flex justify-between text-sm">
        <div className="flex items-center space-x-6">
          <div>
            <p className="text-gray-500 text-xs font-medium uppercase tracking-widest">Current Streak</p>
            <p className="text-2xl font-black text-[#CCFF00]">12 Days</p>
          </div>
          <div>
            <p className="text-gray-500 text-xs font-medium uppercase tracking-widest">Total Active</p>
            <p className="text-2xl font-black text-white">48 Days</p>
          </div>
        </div>
        <div className="hidden sm:block text-right">
          <p className="text-gray-500 text-xs font-medium uppercase tracking-widest">Level</p>
          <p className="text-2xl font-black text-white">Advanced Elite</p>
        </div>
      </div>
    </div>
  );
};

export default Heatmap;
