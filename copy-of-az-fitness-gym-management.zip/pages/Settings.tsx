
import React, { useState } from 'react';
import { 
  User, 
  Bell, 
  Shield, 
  Target, 
  Camera, 
  Save, 
  Check, 
  ChevronRight,
  Eye,
  EyeOff,
  Scale,
  LogOut
} from 'lucide-react';
import { UserProfile } from '../types';

interface SettingsProps {
  user: UserProfile;
  onUpdate: (updatedUser: UserProfile) => void;
  onLogout: () => void;
}

const Settings: React.FC<SettingsProps> = ({ user, onUpdate, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'notifications' | 'privacy' | 'goals'>('profile');
  const [formData, setFormData] = useState<UserProfile>({
    ...user,
    bio: user.bio || '',
    goals: user.goals || ['Muscle Gain', 'Increase Strength'],
    preferences: user.preferences || {
      notifications: true,
      publicProfile: false,
      units: 'metric'
    }
  });
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    onUpdate(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'goals', label: 'My Goals', icon: Target },
    { id: 'notifications', label: 'Alerts', icon: Bell },
    { id: 'privacy', label: 'Privacy', icon: Shield },
  ];

  const goalOptions = [
    'Muscle Gain', 'Weight Loss', 'Endurance', 'Flexibility', 
    'Increase Strength', 'HIIT Focus', 'Olympic Lifting', 'Body Recomposition'
  ];

  const toggleGoal = (goal: string) => {
    const currentGoals = formData.goals || [];
    if (currentGoals.includes(goal)) {
      setFormData({ ...formData, goals: currentGoals.filter(g => g !== goal) });
    } else {
      setFormData({ ...formData, goals: [...currentGoals, goal] });
    }
  };

  return (
    <div className="max-w-4xl mx-auto pb-20">
      <header className="mb-10">
        <h1 className="text-4xl font-black text-white uppercase italic tracking-tighter">
          Member <span className="text-[#CCFF00]">Settings</span>
        </h1>
        <p className="text-gray-500 font-medium">Customize your performance profile and preferences.</p>
      </header>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Navigation Sidebar */}
        <div className="w-full md:w-64 space-y-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`
                w-full flex items-center space-x-3 px-5 py-4 rounded-2xl transition-all font-black uppercase italic tracking-wider text-xs
                ${activeTab === tab.id 
                  ? 'bg-[#CCFF00] text-black shadow-[0_10px_20px_rgba(204,255,0,0.2)]' 
                  : 'text-gray-500 hover:text-white hover:bg-[#1E1E1E] border border-transparent hover:border-[#333]'}
              `}
            >
              <tab.icon size={18} />
              <span>{tab.label}</span>
            </button>
          ))}
          <div className="pt-4 border-t border-[#333] mt-4">
            <button 
              onClick={onLogout}
              className="w-full flex items-center space-x-3 px-5 py-4 rounded-2xl text-red-500 hover:bg-red-500/10 transition-all font-black uppercase italic tracking-wider text-xs"
            >
              <LogOut size={18} />
              <span>Log Out</span>
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1">
          <div className="bg-[#1E1E1E] border border-[#333] rounded-[2.5rem] overflow-hidden">
            {activeTab === 'profile' && (
              <div className="p-8 space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="flex flex-col items-center space-y-4 pb-8 border-b border-[#333]">
                  <div className="relative group">
                    <img 
                      src={formData.avatar} 
                      alt="Avatar" 
                      className="w-32 h-32 rounded-[2rem] object-cover border-4 border-[#333] group-hover:opacity-75 transition-opacity" 
                    />
                    <button className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Camera className="text-[#CCFF00]" size={32} />
                    </button>
                  </div>
                  <div className="text-center">
                    <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">Change Profile Photo</h3>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Recommended: 400x400px</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-gray-500 tracking-widest ml-1">Full Name</label>
                    <input 
                      type="text" 
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-[#252525] border border-[#333] rounded-2xl px-5 py-4 text-white focus:border-[#CCFF00] outline-none transition-all font-medium"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-gray-500 tracking-widest ml-1">Email Address</label>
                    <input 
                      type="email" 
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-[#252525] border border-[#333] rounded-2xl px-5 py-4 text-white focus:border-[#CCFF00] outline-none transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black uppercase text-gray-500 tracking-widest ml-1">Bio / Motivation</label>
                  <textarea 
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    rows={4}
                    placeholder="Tell us your story..."
                    className="w-full bg-[#252525] border border-[#333] rounded-2xl px-5 py-4 text-white focus:border-[#CCFF00] outline-none transition-all font-medium resize-none"
                  />
                </div>
              </div>
            )}

            {activeTab === 'goals' && (
              <div className="p-8 space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="space-y-4">
                  <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">Personal Fitness Goals</h3>
                  <p className="text-sm text-gray-500">Select the targets you want to focus on. We'll tailor your experience based on these selections.</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  {goalOptions.map((goal) => {
                    const isSelected = formData.goals?.includes(goal);
                    return (
                      <button
                        key={goal}
                        onClick={() => toggleGoal(goal)}
                        className={`
                          p-5 rounded-2xl border text-left transition-all group relative overflow-hidden
                          ${isSelected 
                            ? 'bg-[#CCFF00]/10 border-[#CCFF00] text-[#CCFF00]' 
                            : 'bg-[#252525] border-[#333] text-gray-400 hover:border-gray-600'}
                        `}
                      >
                        <span className="font-black uppercase italic tracking-tighter text-sm relative z-10">{goal}</span>
                        {isSelected && <Check size={16} className="absolute right-4 top-1/2 -translate-y-1/2" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="p-8 space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="space-y-4 mb-8">
                  <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">Communication Preferences</h3>
                  <p className="text-sm text-gray-500">Manage how AZ Fitness keeps you updated on your performance.</p>
                </div>

                <div className="space-y-4">
                  {[
                    { key: 'notifications', title: 'Push Notifications', desc: 'Receive daily reminders and progress alerts.' },
                    { key: 'emailNews', title: 'Weekly Reports', desc: 'Get a summary of your stats via email.' }
                  ].map((pref) => (
                    <div key={pref.key} className="flex items-center justify-between p-6 bg-[#252525] rounded-3xl border border-[#333]">
                      <div>
                        <h4 className="font-black text-white uppercase italic tracking-tight">{pref.title}</h4>
                        <p className="text-xs text-gray-500 font-medium mt-1">{pref.desc}</p>
                      </div>
                      <button 
                        onClick={() => setFormData({ 
                          ...formData, 
                          preferences: { ...formData.preferences!, notifications: !formData.preferences?.notifications } 
                        })}
                        className={`
                          w-14 h-8 rounded-full transition-all relative
                          ${formData.preferences?.notifications ? 'bg-[#CCFF00]' : 'bg-[#121212] border border-[#333]'}
                        `}
                      >
                        <div className={`
                          absolute top-1 w-6 h-6 rounded-full transition-all
                          ${formData.preferences?.notifications ? 'right-1 bg-black' : 'left-1 bg-gray-600'}
                        `} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'privacy' && (
              <div className="p-8 space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="space-y-4 mb-8">
                  <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">Privacy & Security</h3>
                  <p className="text-sm text-gray-500">Control who can see your progress and how your data is used.</p>
                </div>

                <div className="space-y-4">
                  <div className="p-6 bg-[#252525] rounded-3xl border border-[#333] flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-[#1A1A1A] rounded-2xl text-[#CCFF00]">
                        {formData.preferences?.publicProfile ? <Eye size={20} /> : <EyeOff size={20} />}
                      </div>
                      <div>
                        <h4 className="font-black text-white uppercase italic tracking-tight">Public Profile</h4>
                        <p className="text-xs text-gray-500 font-medium mt-1">Allow other members to see your achievements.</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setFormData({ 
                        ...formData, 
                        preferences: { ...formData.preferences!, publicProfile: !formData.preferences?.publicProfile } 
                      })}
                      className={`
                        w-14 h-8 rounded-full transition-all relative
                        ${formData.preferences?.publicProfile ? 'bg-[#CCFF00]' : 'bg-[#121212] border border-[#333]'}
                      `}
                    >
                      <div className={`
                        absolute top-1 w-6 h-6 rounded-full transition-all
                        ${formData.preferences?.publicProfile ? 'right-1 bg-black' : 'left-1 bg-gray-600'}
                      `} />
                    </button>
                  </div>

                  <div className="p-6 bg-[#252525] rounded-3xl border border-[#333] flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-[#1A1A1A] rounded-2xl text-blue-400">
                        <Scale size={20} />
                      </div>
                      <div>
                        <h4 className="font-black text-white uppercase italic tracking-tight">Display Units</h4>
                        <p className="text-xs text-gray-500 font-medium mt-1">Choose between Metric (KG) or Imperial (LB).</p>
                      </div>
                    </div>
                    <div className="flex bg-[#121212] p-1 rounded-xl border border-[#333]">
                      <button 
                        onClick={() => setFormData({ ...formData, preferences: { ...formData.preferences!, units: 'metric' } })}
                        className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${formData.preferences?.units === 'metric' ? 'bg-[#CCFF00] text-black' : 'text-gray-500'}`}
                      >
                        KG
                      </button>
                      <button 
                        onClick={() => setFormData({ ...formData, preferences: { ...formData.preferences!, units: 'imperial' } })}
                        className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${formData.preferences?.units === 'imperial' ? 'bg-[#CCFF00] text-black' : 'text-gray-500'}`}
                      >
                        LB
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="p-8 border-t border-[#333] flex items-center justify-between bg-[#1A1A1A]">
              <p className="text-[10px] text-gray-600 font-black uppercase tracking-widest italic">Last updated: Today, 10:24 AM</p>
              <button 
                onClick={handleSave}
                className={`
                  flex items-center space-x-2 px-10 py-4 rounded-2xl font-black uppercase italic tracking-widest transition-all
                  ${isSaved 
                    ? 'bg-green-500 text-white' 
                    : 'bg-[#CCFF00] text-black hover:scale-105 active:scale-95 shadow-[0_10px_30px_-10px_rgba(204,255,0,0.5)]'}
                `}
              >
                {isSaved ? <Check size={20} /> : <Save size={20} />}
                <span>{isSaved ? 'All Changes Saved' : 'Save Changes'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
