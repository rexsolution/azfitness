
import React from 'react';
import { 
  Users, 
  TrendingUp, 
  DollarSign, 
  AlertTriangle,
  Search,
  Filter,
  ArrowUpRight,
  MoreVertical
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

const revenueData = [
  { month: 'Jan', revenue: 4500 },
  { month: 'Feb', revenue: 5200 },
  { month: 'Mar', revenue: 4800 },
  { month: 'Apr', revenue: 6100 },
  { month: 'May', revenue: 5900 },
  { month: 'Jun', revenue: 7500 },
];

const planData = [
  { name: 'Monthly', value: 45 },
  { name: 'Quarterly', value: 25 },
  { name: 'Yearly', value: 30 },
];

const COLORS = ['#CCFF00', '#60A5FA', '#A78BFA'];

const AdminDashboard: React.FC = () => {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-4xl font-black text-white uppercase italic tracking-tighter">
          Owner <span className="text-[#CCFF00]">Terminal</span>
        </h1>
        <p className="text-gray-400 font-medium">Monitoring gym health and membership growth.</p>
      </header>

      {/* Admin Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Active Members', value: '1,284', change: '+12%', icon: Users, color: 'text-[#CCFF00]' },
          { label: 'Monthly Revenue', value: '$12,450', change: '+8%', icon: DollarSign, color: 'text-green-400' },
          { label: 'Expiring Soon', value: '34', change: 'Critical', icon: AlertTriangle, color: 'text-red-400' },
          { label: 'Growth Rate', value: '4.2%', change: '+1.4%', icon: TrendingUp, color: 'text-blue-400' },
        ].map((stat, i) => (
          <div key={i} className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333]">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg bg-[#252525] ${stat.color}`}>
                <stat.icon size={24} />
              </div>
              <span className={`text-xs font-black uppercase italic ${stat.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                {stat.change}
              </span>
            </div>
            <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
            <p className="text-3xl font-black text-white mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333]">
          <h3 className="text-xl font-bold mb-6 uppercase italic">Revenue Insights</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                <XAxis dataKey="month" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{ fill: '#252525' }}
                  contentStyle={{ backgroundColor: '#1E1E1E', border: '1px solid #333', borderRadius: '8px' }}
                />
                <Bar dataKey="revenue" fill="#CCFF00" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333]">
          <h3 className="text-xl font-bold mb-6 uppercase italic">Membership Mix</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={planData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {planData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Member Management Table */}
      <div className="bg-[#1E1E1E] rounded-2xl border border-[#333] overflow-hidden">
        <div className="p-6 border-b border-[#333] flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h3 className="text-xl font-bold uppercase italic">Recent Member Activity</h3>
          <div className="flex items-center space-x-3">
             <div className="relative">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
               <input 
                type="text" 
                placeholder="Search members..."
                className="bg-[#252525] border border-[#333] rounded-xl pl-10 pr-4 py-2 text-sm focus:border-[#CCFF00] outline-none transition-all"
               />
             </div>
             <button className="p-2 bg-[#252525] border border-[#333] rounded-xl text-gray-400 hover:text-white transition-colors">
               <Filter size={20} />
             </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-[#252525] text-gray-500 text-[10px] font-black uppercase tracking-widest">
                <th className="px-6 py-4">Member</th>
                <th className="px-6 py-4">Plan</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Check-in</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#333]">
              {[
                { name: 'Sarah Miller', email: 'sarah@test.com', plan: 'Monthly', status: 'Active', time: '10:24 AM', img: 'https://picsum.photos/id/64/40/40' },
                { name: 'John Davis', email: 'john@test.com', plan: 'Yearly', status: 'Active', time: '09:45 AM', img: 'https://picsum.photos/id/65/40/40' },
                { name: 'Mike Ross', email: 'mike@test.com', plan: 'Monthly', status: 'Expired', time: '3 days ago', img: 'https://picsum.photos/id/66/40/40' },
                { name: 'Emma Wilson', email: 'emma@test.com', plan: 'Quarterly', status: 'Pending', time: 'N/A', img: 'https://picsum.photos/id/67/40/40' },
              ].map((m, i) => (
                <tr key={i} className="hover:bg-[#252525]/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <img src={m.img} className="w-8 h-8 rounded-full" />
                      <div>
                        <p className="font-bold text-white">{m.name}</p>
                        <p className="text-xs text-gray-500">{m.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium text-gray-300">{m.plan}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`
                      text-[10px] font-black uppercase px-2 py-1 rounded-full
                      ${m.status === 'Active' ? 'bg-green-500/10 text-green-400' : m.status === 'Expired' ? 'bg-red-500/10 text-red-400' : 'bg-yellow-500/10 text-yellow-400'}
                    `}>
                      {m.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-400">{m.time}</span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-gray-500 hover:text-white">
                      <MoreVertical size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
