
import React from 'react';
import { Dumbbell, ArrowRight, Github, Chrome, Lock, Mail } from 'lucide-react';
import { UserRole } from '../types';

interface AuthProps {
  onLogin: (role: UserRole) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = React.useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm"></div>
      
      <div className="relative w-full max-w-md">
        <div className="bg-[#1E1E1E] p-8 md:p-10 rounded-[2.5rem] shadow-2xl border border-[#333]">
          <div className="flex flex-col items-center mb-10">
            <div className="w-16 h-16 bg-[#CCFF00] rounded-2xl flex items-center justify-center mb-4 shadow-[0_0_30px_rgba(204,255,0,0.3)]">
              < Dumbbell size={32} color="#000" />
            </div>
            <h1 className="text-3xl font-black text-white italic uppercase tracking-tighter">
              AZ <span className="text-[#CCFF00]">Fitness</span>
            </h1>
            <p className="text-gray-500 font-bold uppercase text-[10px] tracking-[0.3em] mt-2">Professional Fitness Ecosystem</p>
          </div>

          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            {isRegistering && (
               <div className="space-y-2">
                <label className="text-xs font-black uppercase text-gray-500 tracking-widest ml-1">Full Name</label>
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="John Doe"
                    className="w-full bg-[#252525] border border-[#333] rounded-2xl px-4 py-4 text-white placeholder-gray-600 focus:border-[#CCFF00] outline-none transition-all"
                  />
                </div>
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-gray-500 tracking-widest ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-600" size={20} />
                <input 
                  type="email" 
                  placeholder="alex@azfitness.com"
                  className="w-full bg-[#252525] border border-[#333] rounded-2xl px-4 py-4 text-white placeholder-gray-600 focus:border-[#CCFF00] outline-none transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-gray-500 tracking-widest ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-600" size={20} />
                <input 
                  type="password" 
                  placeholder="••••••••"
                  className="w-full bg-[#252525] border border-[#333] rounded-2xl px-4 py-4 text-white placeholder-gray-600 focus:border-[#CCFF00] outline-none transition-all"
                />
              </div>
            </div>

            <div className="flex flex-col space-y-4 pt-4">
              <button 
                onClick={() => onLogin('member')}
                className="w-full bg-[#CCFF00] text-black py-4 rounded-2xl font-black uppercase italic tracking-widest flex items-center justify-center space-x-2 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_10px_30px_-10px_rgba(204,255,0,0.4)]"
              >
                <span>{isRegistering ? 'Create Account' : 'Sign In'}</span>
                <ArrowRight size={20} />
              </button>
              
              <div className="flex items-center space-x-2 text-gray-500 text-xs py-2">
                <div className="h-px flex-1 bg-[#333]"></div>
                <span className="font-bold uppercase tracking-widest">Or login as admin</span>
                <div className="h-px flex-1 bg-[#333]"></div>
              </div>

              <button 
                onClick={() => onLogin('admin')}
                className="w-full bg-[#121212] border border-[#333] text-white py-4 rounded-2xl font-black uppercase italic tracking-widest hover:bg-[#252525] transition-all"
              >
                Gym Owner Login
              </button>
            </div>
          </form>

          <p className="mt-8 text-center text-sm text-gray-500 font-bold">
            {isRegistering ? 'Already a member?' : "Don't have an account?"}
            <button 
              onClick={() => setIsRegistering(!isRegistering)}
              className="text-[#CCFF00] ml-2 hover:underline"
            >
              {isRegistering ? 'Sign In' : 'Join AZ Fitness'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
