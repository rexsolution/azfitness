
import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  CheckCircle2, 
  History, 
  Play, 
  Save,
  ChevronDown,
  Search,
  Timer,
  X
} from 'lucide-react';
import { EXERCISE_LIBRARY, MOCK_ROUTINES } from '../constants';
import { WorkoutSet } from '../types';

const WorkoutLog: React.FC = () => {
  const [isLogging, setIsLogging] = React.useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState('');
  const [seconds, setSeconds] = useState(0);
  const [currentSession, setCurrentSession] = React.useState<{
    name: string;
    exercises: { name: string; sets: WorkoutSet[] }[];
  }>({
    name: 'New Session',
    exercises: []
  });

  // Debounce Search Query
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 300);

    return () => {
      clearTimeout(handler);
    };
  }, [searchQuery]);

  // Timer Effect
  useEffect(() => {
    let interval: any;
    if (isLogging) {
      interval = setInterval(() => {
        setSeconds(prev => prev + 1);
      }, 1000);
    } else {
      setSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isLogging]);

  const formatTime = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs > 0 ? hrs + ':' : ''}${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startRoutine = (id: string) => {
    const routine = MOCK_ROUTINES.find(r => r.id === id);
    if (!routine) return;
    
    setCurrentSession({
      name: routine.name,
      exercises: routine.exercises.map(e => ({
        name: e.name,
        sets: Array.from({ length: e.defaultSets }, () => ({ reps: e.defaultReps, weight: 0, completed: false }))
      }))
    });
    setIsLogging(true);
    setSeconds(0);
  };

  const addExercise = (name: string) => {
    setCurrentSession(prev => ({
      ...prev,
      exercises: [...prev.exercises, { name, sets: [{ reps: 10, weight: 0, completed: false }] }]
    }));
    setSearchQuery('');
  };

  const addSet = (exerciseIndex: number) => {
    const updated = [...currentSession.exercises];
    const lastSet = updated[exerciseIndex].sets[updated[exerciseIndex].sets.length - 1];
    updated[exerciseIndex].sets.push({ ...lastSet, completed: false });
    setCurrentSession({ ...currentSession, exercises: updated });
  };

  const updateSet = (exerciseIndex: number, setIndex: number, field: keyof WorkoutSet, value: any) => {
    const updated = [...currentSession.exercises];
    (updated[exerciseIndex].sets[setIndex] as any)[field] = value;
    setCurrentSession({ ...currentSession, exercises: updated });
  };

  const toggleSetComplete = (exerciseIndex: number, setIndex: number) => {
    const updated = [...currentSession.exercises];
    updated[exerciseIndex].sets[setIndex].completed = !updated[exerciseIndex].sets[setIndex].completed;
    setCurrentSession({ ...currentSession, exercises: updated });
  };

  const removeExercise = (index: number) => {
    const updated = [...currentSession.exercises];
    updated.splice(index, 1);
    setCurrentSession({ ...currentSession, exercises: updated });
  };

  const filteredExercises = EXERCISE_LIBRARY.filter(ex => 
    ex.toLowerCase().includes(debouncedSearchQuery.toLowerCase())
  );

  if (isLogging) {
    return (
      <div className="max-w-4xl mx-auto pb-24">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 sticky top-0 bg-[#121212]/95 backdrop-blur-md py-4 z-10 border-b border-[#333] px-2">
          <div>
            <input 
              type="text" 
              value={currentSession.name}
              onChange={(e) => setCurrentSession({...currentSession, name: e.target.value})}
              className="text-2xl font-black bg-transparent border-none focus:ring-0 text-[#CCFF00] uppercase italic tracking-tighter w-full"
            />
            <div className="flex items-center gap-4 mt-1">
              <p className="text-gray-500 font-bold flex items-center gap-2 text-xs uppercase tracking-widest">
                <History size={14} className="animate-pulse" /> Recording...
              </p>
              <div className="flex items-center gap-1.5 text-white font-black text-sm bg-[#252525] px-3 py-1 rounded-full border border-[#333]">
                <Timer size={14} className="text-[#CCFF00]" />
                {formatTime(seconds)}
              </div>
            </div>
          </div>
          <button 
            onClick={() => setIsLogging(false)}
            className="mt-4 md:mt-0 flex items-center space-x-2 bg-[#CCFF00] text-black px-8 py-3 rounded-xl font-black uppercase italic tracking-widest hover:scale-105 transition-all shadow-[0_0_20px_rgba(204,255,0,0.3)]"
          >
            <Save size={20} />
            <span>Finish Session</span>
          </button>
        </div>

        <div className="space-y-8">
          {currentSession.exercises.map((ex, exIdx) => {
            const completedSets = ex.sets.filter(s => s.completed).length;
            const progress = (completedSets / ex.sets.length) * 100;
            
            return (
              <div key={exIdx} className="bg-[#1E1E1E] rounded-3xl border border-[#333] overflow-hidden group hover:border-[#444] transition-colors">
                <div className="p-5 bg-[#252525] flex items-center justify-between border-b border-[#333]">
                  <div>
                    <h3 className="font-black text-lg text-white uppercase italic tracking-wider">{ex.name}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="w-32 h-1.5 bg-[#1A1A1A] rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-[#CCFF00] transition-all duration-500" 
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">
                        {completedSets}/{ex.sets.length} Sets
                      </span>
                    </div>
                  </div>
                  <button onClick={() => removeExercise(exIdx)} className="text-gray-600 hover:text-red-500 transition-colors p-2 rounded-lg hover:bg-red-500/10">
                    <Trash2 size={20} />
                  </button>
                </div>
                <div className="p-6">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="text-[10px] font-black uppercase text-gray-500 tracking-[0.2em]">
                        <th className="pb-4 w-12 text-center">Set</th>
                        <th className="pb-4">KG / Weight</th>
                        <th className="pb-4">Reps</th>
                        <th className="pb-4 w-12 text-center">Done</th>
                      </tr>
                    </thead>
                    <tbody className="space-y-3">
                      {ex.sets.map((set, sIdx) => (
                        <tr key={sIdx} className={`group transition-opacity ${set.completed ? 'opacity-50' : 'opacity-100'}`}>
                          <td className="py-2 text-center text-gray-400 font-bold">{sIdx + 1}</td>
                          <td className="py-2">
                            <input 
                              type="number" 
                              value={set.weight}
                              onChange={(e) => updateSet(exIdx, sIdx, 'weight', Number(e.target.value))}
                              className="w-24 bg-[#252525] border border-[#333] rounded-xl p-2.5 text-white font-black text-center focus:border-[#CCFF00] outline-none"
                            />
                          </td>
                          <td className="py-2">
                             <input 
                              type="number" 
                              value={set.reps}
                              onChange={(e) => updateSet(exIdx, sIdx, 'reps', Number(e.target.value))}
                              className="w-24 bg-[#252525] border border-[#333] rounded-xl p-2.5 text-white font-black text-center focus:border-[#CCFF00] outline-none"
                            />
                          </td>
                          <td className="py-2 text-center">
                            <button 
                              onClick={() => toggleSetComplete(exIdx, sIdx)}
                              className={`transition-all ${set.completed ? 'text-[#CCFF00] scale-110' : 'text-[#333] hover:text-[#CCFF00]'}`}
                            >
                              <CheckCircle2 size={28} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <button 
                    onClick={() => addSet(exIdx)}
                    className="w-full mt-6 py-3 border border-dashed border-[#333] hover:border-[#CCFF00] hover:text-[#CCFF00] rounded-xl text-xs font-black uppercase transition-all tracking-widest"
                  >
                    + Add Set
                  </button>
                </div>
              </div>
            );
          })}

          <div className="pt-8 border-t border-[#333]">
             <div className="flex items-center justify-between mb-6">
               <h4 className="text-gray-400 text-xs font-black uppercase tracking-widest">Add Exercise</h4>
               <div className="relative w-48 sm:w-64">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={14} />
                 <input 
                  type="text"
                  placeholder="Find exercise..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#1A1A1A] border border-[#333] rounded-xl pl-9 pr-10 py-2 text-xs text-white focus:border-[#CCFF00] outline-none transition-all"
                 />
                 {searchQuery && (
                   <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors"
                   >
                     <X size={14} />
                   </button>
                 )}
               </div>
             </div>
             
             <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
               {filteredExercises.slice(0, 12).map((name) => (
                 <button 
                  key={name} 
                  onClick={() => addExercise(name)}
                  className="bg-[#252525] hover:bg-[#CCFF00] hover:text-black border border-[#333] p-4 rounded-2xl text-[10px] font-black uppercase italic tracking-wider text-center transition-all truncate"
                 >
                   {name}
                 </button>
               ))}
               {filteredExercises.length === 0 && (
                 <div className="col-span-full py-8 text-center bg-[#1A1A1A] rounded-2xl border border-[#333]">
                   <p className="text-gray-500 text-sm italic">No exercises found matching "{debouncedSearchQuery}"</p>
                 </div>
               )}
             </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <header>
        <h1 className="text-4xl font-black text-white uppercase italic tracking-tighter">
          Training <span className="text-[#CCFF00]">Library</span>
        </h1>
        <p className="text-gray-400 font-medium">Select a routine or start a custom empty session.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Custom Start */}
        <div className="bg-[#1E1E1E] p-8 rounded-3xl border-2 border-dashed border-[#333] hover:border-[#CCFF00] transition-all group flex flex-col items-center justify-center text-center">
           <div className="w-16 h-16 bg-[#252525] rounded-2xl flex items-center justify-center mb-6 group-hover:bg-[#CCFF00] transition-all">
             <Plus size={32} className="text-[#CCFF00] group-hover:text-black transition-all" />
           </div>
           <h3 className="text-xl font-bold mb-2 uppercase italic">Custom Session</h3>
           <p className="text-sm text-gray-500 mb-6 px-4">Build your own workout from scratch exercise by exercise.</p>
           <button 
            onClick={() => { setIsLogging(true); setCurrentSession({ name: 'Custom Session', exercises: [] }); }}
            className="w-full py-3 bg-[#252525] group-hover:bg-white group-hover:text-black rounded-xl font-black uppercase tracking-widest text-sm transition-all"
           >
             Start Empty
           </button>
        </div>

        {/* Existing Routines */}
        {MOCK_ROUTINES.map((routine) => (
          <div key={routine.id} className="bg-[#1E1E1E] p-8 rounded-3xl border border-[#333] hover:translate-y-[-4px] transition-all">
            <h3 className="text-xl font-black mb-4 uppercase italic text-white leading-tight">{routine.name}</h3>
            <div className="space-y-3 mb-8">
              {routine.exercises.map((e, i) => (
                <div key={i} className="flex items-center justify-between text-sm">
                  <span className="text-gray-400 font-medium">{e.name}</span>
                  <span className="text-[#CCFF00] font-bold">{e.defaultSets} Sets</span>
                </div>
              ))}
            </div>
            <button 
              onClick={() => startRoutine(routine.id)}
              className="w-full py-4 bg-[#CCFF00] text-black rounded-xl font-black uppercase tracking-widest text-sm flex items-center justify-center space-x-2"
            >
              <Play size={18} fill="currentColor" />
              <span>Start Routine</span>
            </button>
          </div>
        ))}
      </div>

      <div className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333]">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold uppercase italic">Recent History</h3>
          <button className="text-xs font-bold text-[#CCFF00] uppercase tracking-widest flex items-center">
            View All <ChevronDown size={14} className="ml-1" />
          </button>
        </div>
        <div className="space-y-4">
          {[
            { name: 'Push Day', date: 'Yesterday', volume: '4.2k kg' },
            { name: 'Pull Day', date: '3 days ago', volume: '5.8k kg' },
            { name: 'Leg Day', date: 'Last week', volume: '8.1k kg' },
          ].map((h, i) => (
            <div key={i} className="flex items-center justify-between p-4 bg-[#252525] rounded-xl border border-[#333]">
              <div>
                <p className="font-bold text-white uppercase italic">{h.name}</p>
                <p className="text-xs text-gray-500 font-medium">{h.date}</p>
              </div>
              <div className="text-right">
                <p className="text-[#CCFF00] font-black italic">{h.volume}</p>
                <p className="text-[10px] text-gray-500 uppercase font-black">Total Volume</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WorkoutLog;
