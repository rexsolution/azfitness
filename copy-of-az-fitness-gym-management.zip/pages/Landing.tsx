
import React, { useState, useRef } from 'react';
import { 
  Dumbbell, 
  CheckCircle2, 
  Zap, 
  Shield, 
  Clock, 
  Scan, 
  ArrowRight, 
  Instagram, 
  Twitter, 
  Facebook,
  Camera,
  X,
  AlertCircle,
  RefreshCw,
  Smartphone,
  QrCode
} from 'lucide-react';
import { PricingPlan, UserRole } from '../types';

interface LandingProps {
  onLogin: (role: UserRole) => void;
  onGoToLogin: () => void;
}

const PLANS: PricingPlan[] = [
  {
    name: "Basic",
    price: "$29",
    period: "month",
    features: ["Access to Gym Floor", "Locker Room Access", "1 Free Trainer Session", "Basic App Features"],
  },
  {
    name: "Pro Elite",
    price: "$49",
    period: "month",
    features: ["24/7 Access", "All Group Classes", "Sauna & Steam Room", "Advanced Tracking", "Monthly Progress Report"],
    recommended: true
  },
  {
    name: "Annual Champion",
    price: "$399",
    period: "year",
    features: ["All Pro Features", "Free Supplement Starter Pack", "Personalized Nutrition Plan", "2 Months Free"],
  }
];

const RULES = [
  "Always re-rack your weights after use.",
  "Wipe down equipment after every set.",
  "Respect others' personal space and focus.",
  "Proper gym attire and clean shoes are mandatory.",
  "No loud phone calls on the gym floor."
];

// Simple SVG Barcode Component for demo
const BarcodeGraphic = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg">
    <rect x="0" y="0" width="2" height="40" fill="currentColor" />
    <rect x="4" y="0" width="1" height="40" fill="currentColor" />
    <rect x="7" y="0" width="3" height="40" fill="currentColor" />
    <rect x="12" y="0" width="1" height="40" fill="currentColor" />
    <rect x="15" y="0" width="2" height="40" fill="currentColor" />
    <rect x="19" y="0" width="4" height="40" fill="currentColor" />
    <rect x="25" y="0" width="1" height="40" fill="currentColor" />
    <rect x="28" y="0" width="2" height="40" fill="currentColor" />
    <rect x="32" y="0" width="1" height="40" fill="currentColor" />
    <rect x="35" y="0" width="3" height="40" fill="currentColor" />
    <rect x="40" y="0" width="2" height="40" fill="currentColor" />
    <rect x="44" y="0" width="1" height="40" fill="currentColor" />
    <rect x="47" y="0" width="4" height="40" fill="currentColor" />
    <rect x="53" y="0" width="2" height="40" fill="currentColor" />
    <rect x="57" y="0" width="1" height="40" fill="currentColor" />
    <rect x="60" y="0" width="3" height="40" fill="currentColor" />
    <rect x="65" y="0" width="1" height="40" fill="currentColor" />
    <rect x="68" y="0" width="2" height="40" fill="currentColor" />
    <rect x="72" y="0" width="4" height="40" fill="currentColor" />
    <rect x="78" y="0" width="1" height="40" fill="currentColor" />
    <rect x="81" y="0" width="2" height="40" fill="currentColor" />
    <rect x="85" y="0" width="1" height="40" fill="currentColor" />
    <rect x="88" y="0" width="3" height="40" fill="currentColor" />
    <rect x="93" y="0" width="2" height="40" fill="currentColor" />
    <rect x="97" y="0" width="3" height="40" fill="currentColor" />
  </svg>
);

const Landing: React.FC<LandingProps> = ({ onLogin, onGoToLogin }) => {
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scanStatus, setScanStatus] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startScanner = async () => {
    setIsScannerOpen(true);
    setScanStatus('scanning');
    setErrorMessage('');
    
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera API not supported in this browser.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        try {
          await videoRef.current.play();
        } catch (playErr) {
          console.error("Video play error:", playErr);
        }
      }

      setTimeout(() => {
        if (isScannerOpen) {
           setScanStatus('success');
           setTimeout(() => {
             onLogin('member');
           }, 1500);
        }
      }, 3000);

    } catch (err: any) {
      console.error("Camera access error:", err);
      setScanStatus('error');
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setErrorMessage("Camera access was denied. Please enable permissions in your browser settings.");
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setErrorMessage("No camera found on this device.");
      } else {
        setErrorMessage(err.message || "Failed to access camera. Please try again.");
      }
    }
  };

  const closeScanner = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsScannerOpen(false);
    setScanStatus('idle');
    setErrorMessage('');
  };

  const simulateScan = () => {
    setScanStatus('success');
    setTimeout(() => {
      onLogin('member');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#121212] text-white selection:bg-[#CCFF00] selection:text-black">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-[#121212]/80 backdrop-blur-md border-b border-white/5 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-[#CCFF00] rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(204,255,0,0.3)]">
            <Dumbbell size={24} color="#000" />
          </div>
          <span className="text-xl font-black uppercase italic tracking-tighter">AZ <span className="text-[#CCFF00]">Fitness</span></span>
        </div>
        <div className="hidden md:flex items-center space-x-8 text-sm font-bold uppercase tracking-widest text-gray-400">
          <a href="#plans" className="hover:text-[#CCFF00] transition-colors">Plans</a>
          <a href="#rules" className="hover:text-[#CCFF00] transition-colors">Rules</a>
          <a href="#access" className="hover:text-[#CCFF00] transition-colors">Entry</a>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={onGoToLogin}
            className="text-sm font-bold uppercase tracking-widest hover:text-[#CCFF00] transition-colors"
          >
            Login
          </button>
          <button 
            onClick={startScanner}
            className="bg-[#CCFF00] text-black px-5 py-2.5 rounded-xl font-black uppercase italic tracking-widest text-xs flex items-center space-x-2 hover:scale-105 active:scale-95 transition-all shadow-[0_0_20px_rgba(204,255,0,0.3)]"
          >
            <Scan size={16} />
            <span>Check In</span>
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?q=80&w=2070&auto=format&fit=crop" 
            className="w-full h-full object-cover opacity-30 scale-105 animate-slow-zoom" 
            alt="Gym" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent"></div>
        </div>
        
        <div className="relative z-10 text-center px-6">
          <div className="inline-flex items-center space-x-2 bg-[#CCFF00]/10 border border-[#CCFF00]/20 px-4 py-2 rounded-full mb-8">
            <Zap size={16} className="text-[#CCFF00]" />
            <span className="text-[#CCFF00] text-xs font-black uppercase tracking-[0.2em]">The Elite Training Ground</span>
          </div>
          <h1 className="text-6xl md:text-8xl font-black uppercase italic leading-none tracking-tighter mb-6">
            Evolve Your <br />
            <span className="text-transparent stroke-text">Performance</span>
          </h1>
          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 font-medium">
            Join the most advanced fitness ecosystem. Track your progress, dominate your routines, and join a community of champions.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={onGoToLogin}
              className="w-full sm:w-auto bg-[#CCFF00] text-black px-10 py-5 rounded-2xl font-black uppercase italic tracking-widest flex items-center justify-center space-x-2 hover:scale-105 transition-all shadow-[0_10px_30px_rgba(204,255,0,0.3)]"
            >
              <span>Join AZ Fitness</span>
              <ArrowRight size={20} />
            </button>
            <button 
              onClick={startScanner}
              className="w-full sm:w-auto bg-white/5 border border-white/10 text-white px-10 py-5 rounded-2xl font-black uppercase italic tracking-widest hover:bg-white/10 transition-all flex items-center justify-center space-x-3"
            >
              <Scan size={20} className="text-[#CCFF00]" />
              <span>Express Entry</span>
            </button>
          </div>
        </div>
      </section>

      {/* Digital Access Section (The Barcode to scan) */}
      <section id="access" className="py-24 px-6 bg-[#1A1A1A] border-y border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2 space-y-8">
            <div className="w-12 h-12 bg-[#CCFF00] rounded-xl flex items-center justify-center text-black">
              <Smartphone size={28} />
            </div>
            <h2 className="text-5xl font-black uppercase italic tracking-tighter leading-none">Seamless <br /><span className="text-[#CCFF00]">Digital Entry</span></h2>
            <p className="text-gray-400 text-lg font-medium">No more physical cards. Log in or check into the gym instantly using our integrated barcode scanner. Your performance journey starts with a simple scan.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="p-6 bg-[#252525] rounded-2xl border border-white/5">
                <h4 className="font-black text-[#CCFF00] uppercase italic mb-2">Instant Log</h4>
                <p className="text-xs text-gray-500">Scan at the front desk to automatically log your attendance and open your dashboard.</p>
              </div>
              <div className="p-6 bg-[#252525] rounded-2xl border border-white/5">
                <h4 className="font-black text-[#CCFF00] uppercase italic mb-2">Member ID</h4>
                <p className="text-xs text-gray-500">Your unique member code is stored securely in the AZ Fitness app for 24/7 access.</p>
              </div>
            </div>
          </div>

          {/* Scannable Barcode Mockup */}
          <div className="lg:w-1/2 flex justify-center">
             <div className="relative group p-8 bg-[#121212] rounded-[3rem] border border-[#333] shadow-2xl transition-all hover:border-[#CCFF00]/30">
               <div className="absolute -top-6 -right-6 bg-[#CCFF00] text-black px-4 py-2 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg animate-bounce">
                 Scan This Code
               </div>
               <div className="bg-white p-12 rounded-[2rem] flex flex-col items-center">
                 <p className="text-black font-black uppercase italic text-lg mb-6 tracking-widest">AZ-MEMBER-PASS</p>
                 <BarcodeGraphic className="w-64 h-32 text-black mb-6" />
                 <p className="text-gray-400 font-mono text-[10px]">#0021-X942-ELITE</p>
               </div>
               <div className="mt-8 flex items-center justify-between text-[#CCFF00]">
                 <div className="flex items-center space-x-2">
                   <QrCode size={20} />
                   <span className="text-[10px] font-black uppercase tracking-widest">Digital ID Ready</span>
                 </div>
                 <button 
                  onClick={startScanner}
                  className="bg-[#CCFF00] text-black p-3 rounded-full hover:scale-110 transition-transform shadow-lg"
                 >
                   <Scan size={20} />
                 </button>
               </div>
             </div>
          </div>
        </div>
      </section>

      {/* Subscription Plans */}
      <section id="plans" className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-black uppercase italic tracking-tighter mb-4">Choose Your <span className="text-[#CCFF00]">Plan</span></h2>
            <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">Flexible memberships for every athlete</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PLANS.map((plan, i) => (
              <div 
                key={i} 
                className={`
                  relative bg-[#1A1A1A] p-10 rounded-[2.5rem] border transition-all duration-500 hover:translate-y-[-10px]
                  ${plan.recommended ? 'border-[#CCFF00] shadow-[0_20px_50px_rgba(204,255,0,0.1)]' : 'border-white/5'}
                `}
              >
                {plan.recommended && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#CCFF00] text-black text-[10px] font-black uppercase px-4 py-1.5 rounded-full tracking-widest">
                    Recommended
                  </div>
                )}
                <h3 className="text-2xl font-black uppercase italic mb-2">{plan.name}</h3>
                <div className="flex items-baseline space-x-1 mb-8">
                  <span className="text-5xl font-black">{plan.price}</span>
                  <span className="text-gray-500 font-bold uppercase text-xs">/ {plan.period}</span>
                </div>
                <div className="space-y-4 mb-10">
                  {plan.features.map((feat, idx) => (
                    <div key={idx} className="flex items-start space-x-3 text-sm font-medium text-gray-400">
                      <CheckCircle2 size={18} className="text-[#CCFF00] shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
                <button 
                  onClick={onGoToLogin}
                  className={`
                    w-full py-5 rounded-2xl font-black uppercase italic tracking-widest text-sm transition-all
                    ${plan.recommended ? 'bg-[#CCFF00] text-black hover:scale-105' : 'bg-white/5 text-white hover:bg-white/10'}
                  `}
                >
                  Get Started
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gym Rules Section */}
      <section id="rules" className="py-32 px-6 bg-[#1A1A1A] relative overflow-hidden">
        <div className="absolute right-0 top-0 text-[15rem] font-black text-white/5 uppercase italic select-none -mr-40 pointer-events-none">AZ-Rules</div>
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div>
            <h2 className="text-5xl font-black uppercase italic tracking-tighter mb-8 leading-none">The AZ Fitness <br /><span className="text-[#CCFF00]">Athlete Code</span></h2>
            <p className="text-gray-400 text-lg mb-12 font-medium">We maintain a high-standard environment for high-standard athletes. Follow our core rules to ensure the best training experience for everyone.</p>
            <div className="space-y-6">
              {RULES.map((rule, i) => (
                <div key={i} className="flex items-center space-x-5 group">
                  <div className="w-10 h-10 bg-[#252525] group-hover:bg-[#CCFF00] transition-colors rounded-xl flex items-center justify-center text-xs font-black group-hover:text-black">
                    0{i+1}
                  </div>
                  <span className="text-gray-300 font-bold uppercase tracking-tight text-sm group-hover:text-white transition-colors">{rule}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="relative group">
            <div className="absolute -inset-4 bg-[#CCFF00]/10 rounded-3xl blur-2xl group-hover:bg-[#CCFF00]/20 transition-all duration-700"></div>
            <img 
              src="https://images.unsplash.com/photo-1593079831268-3381b0db4a77?q=80&w=2069&auto=format&fit=crop" 
              className="relative w-full h-[600px] object-cover rounded-3xl grayscale hover:grayscale-0 transition-all duration-700 shadow-2xl" 
              alt="Gym Athlete" 
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#121212] pt-24 pb-12 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-8">
                <div className="w-8 h-8 bg-[#CCFF00] rounded-lg flex items-center justify-center">
                  <Dumbbell size={20} color="#000" />
                </div>
                <span className="text-xl font-black uppercase italic tracking-tighter">AZ <span className="text-[#CCFF00]">Fitness</span></span>
              </div>
              <p className="text-gray-500 max-w-sm mb-8 font-medium">
                Pushing boundaries, breaking plateaus. AZ Fitness is the ultimate sanctuary for those dedicated to physical excellence.
              </p>
              <div className="flex space-x-6">
                <button className="text-gray-500 hover:text-[#CCFF00] transition-colors"><Instagram size={24} /></button>
                <button className="text-gray-500 hover:text-[#CCFF00] transition-colors"><Twitter size={24} /></button>
                <button className="text-gray-500 hover:text-[#CCFF00] transition-colors"><Facebook size={24} /></button>
              </div>
            </div>
            <div>
              <h4 className="text-sm font-black uppercase tracking-widest text-white mb-8">Quick Links</h4>
              <ul className="space-y-4 text-sm font-bold text-gray-500">
                <li><a href="#" className="hover:text-[#CCFF00] transition-colors">Find a Location</a></li>
                <li><a href="#" className="hover:text-[#CCFF00] transition-colors">Class Schedule</a></li>
                <li><a href="#" className="hover:text-[#CCFF00] transition-colors">Personal Training</a></li>
                <li><a href="#" className="hover:text-[#CCFF00] transition-colors">Success Stories</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-black uppercase tracking-widest text-white mb-8">Contact</h4>
              <ul className="space-y-4 text-sm font-bold text-gray-500">
                <li>support@azfitness.com</li>
                <li>+1 (555) 948-2022</li>
                <li>123 Alpha Zen Blvd</li>
                <li>Elite District, CA</li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-center justify-between pt-12 border-t border-white/5 text-[10px] font-black uppercase tracking-[0.3em] text-gray-600">
            <span>&copy; 2024 AZ Fitness Performance Systems. All Rights Reserved.</span>
            <div className="flex space-x-8 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Barcode Scanner Modal */}
      {isScannerOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={closeScanner}></div>
          <div className="relative w-full max-w-lg bg-[#1E1E1E] rounded-[3rem] border border-[#333] shadow-2xl overflow-hidden p-10 text-center animate-in zoom-in duration-300">
            <button onClick={closeScanner} className="absolute top-6 right-6 text-gray-500 hover:text-white transition-colors">
              <X size={24} />
            </button>
            
            <div className="mb-8">
              <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 ${scanStatus === 'error' ? 'bg-red-500/10' : 'bg-[#CCFF00]/10'}`}>
                {scanStatus === 'error' ? (
                  <AlertCircle size={40} className="text-red-500" />
                ) : (
                  <Scan size={40} className="text-[#CCFF00]" />
                )}
              </div>
              <h3 className="text-3xl font-black uppercase italic tracking-tighter">Member <span className={scanStatus === 'error' ? 'text-red-500' : 'text-[#CCFF00]'}>Check-In</span></h3>
              <p className="text-gray-500 font-bold uppercase text-[10px] tracking-[0.3em] mt-2">
                {scanStatus === 'error' ? 'Scanner Error' : 'Scan your ID barcode for entry'}
              </p>
            </div>

            <div className={`relative aspect-square max-w-[300px] mx-auto rounded-[2rem] overflow-hidden border-2 mb-8 ${scanStatus === 'error' ? 'border-red-500/50' : 'border-[#333]'} bg-black`}>
              {scanStatus === 'scanning' && (
                <>
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline 
                    className="w-full h-full object-cover grayscale opacity-50"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-64 h-0.5 bg-[#CCFF00] shadow-[0_0_15px_rgba(204,255,0,1)] animate-scan-line"></div>
                  </div>
                  <div className="absolute inset-8 border border-white/10 rounded-2xl flex items-center justify-center">
                     <Camera size={48} className="text-white/20 animate-pulse" />
                  </div>
                </>
              )}
              {scanStatus === 'success' && (
                <div className="absolute inset-0 bg-[#CCFF00] flex flex-col items-center justify-center text-black animate-in fade-in zoom-in duration-300">
                  <CheckCircle2 size={80} className="mb-4" />
                  <span className="text-2xl font-black uppercase italic tracking-tighter">Check-in Verified</span>
                  <span className="text-xs font-bold uppercase tracking-widest mt-2">Welcome Back, Athlete</span>
                </div>
              )}
              {scanStatus === 'error' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                  <AlertCircle size={48} className="text-red-500 mb-4" />
                  <p className="text-sm font-bold text-gray-400 mb-6">{errorMessage}</p>
                  <button 
                    onClick={startScanner}
                    className="flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-white/10 transition-colors"
                  >
                    <RefreshCw size={14} />
                    <span>Try Again</span>
                  </button>
                  <button 
                    onClick={simulateScan}
                    className="mt-4 text-[#CCFF00] text-[10px] font-black uppercase tracking-widest hover:underline"
                  >
                    Skip to Login (Simulate)
                  </button>
                </div>
              )}
            </div>

            <div className={`flex items-center justify-center space-x-3 font-bold text-xs uppercase tracking-widest ${scanStatus === 'error' ? 'text-red-500' : 'text-[#CCFF00]'}`}>
              {scanStatus === 'scanning' ? (
                <>
                  <Clock size={16} className="animate-spin" />
                  <span>Align code within the frame...</span>
                </>
              ) : scanStatus === 'error' ? (
                <span>Setup incomplete</span>
              ) : (
                <>
                  <AlertCircle size={16} />
                  <span>Preparing performance data...</span>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      <style>{`
        .stroke-text {
          -webkit-text-stroke: 1px #CCFF00;
          color: transparent;
        }
        @keyframes slow-zoom {
          from { transform: scale(1); }
          to { transform: scale(1.1); }
        }
        .animate-slow-zoom {
          animation: slow-zoom 20s linear infinite alternate;
        }
        @keyframes scan-line {
          0% { transform: translateY(-100px); }
          100% { transform: translateY(100px); }
        }
        .animate-scan-line {
          animation: scan-line 2s ease-in-out infinite alternate;
        }
      `}</style>
    </div>
  );
};

export default Landing;
