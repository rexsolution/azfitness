
import React from 'react';
import { 
  TrendingUp, 
  Calendar, 
  Clock, 
  Zap, 
  Trophy,
  ArrowRight,
  Dumbbell,
  Smartphone,
  Info
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import Heatmap from '../components/Heatmap';

const weightData = [
  { day: 'Mon', weight: 185 },
  { day: 'Tue', weight: 184.5 },
  { day: 'Wed', weight: 186 },
  { day: 'Thu', weight: 184 },
  { day: 'Fri', weight: 183.5 },
  { day: 'Sat', weight: 183.8 },
  { day: 'Sun', weight: 182.5 },
];

const activityData = [
  { name: 'Week 1', hours: 4 },
  { name: 'Week 2', hours: 7 },
  { name: 'Week 3', hours: 5 },
  { name: 'Week 4', hours: 9 },
  { name: 'Week 5', hours: 8 },
];

const BarcodeGraphic = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg">
    <rect x="0" y="0" width="2" height="40" fill="currentColor" />
    <rect x="4" y="0" width="1" height="40" fill="currentColor" />
    <rect x="7" y="0" width="3" height="40" fill="currentColor" />
    <rect x="12" y="0" width="1" height="40" fill="currentColor" />
    <rect x="15" y="0" width="2" height="40" fill="currentColor" />
    <rect x="19" y="0" width="4" height="40" fill="currentColor" />
    <rect x="25" y="0" width="1" height="40" fill="currentColor" />
    <rect x="28" y="0" width="2" height="40" fill="currentColor" />
    <rect x="32" y="0" width="1" height="40" fill="currentColor" />
    <rect x="35" y="0" width="3" height="40" fill="currentColor" />
    <rect x="40" y="0" width="2" height="40" fill="currentColor" />
    <rect x="44" y="0" width="1" height="40" fill="currentColor" />
    <rect x="47" y="0" width="4" height="40" fill="currentColor" />
    <rect x="53" y="0" width="2" height="40" fill="currentColor" />
    <rect x="57" y="0" width="1" height="40" fill="currentColor" />
    <rect x="60" y="0" width="3" height="40" fill="currentColor" />
    <rect x="65" y="0" width="1" height="40" fill="currentColor" />
    <rect x="68" y="0" width="2" height="40" fill="currentColor" />
    <rect x="72" y="0" width="4" height="40" fill="currentColor" />
    <rect x="78" y="0" width="1" height="40" fill="currentColor" />
    <rect x="81" y="0" width="2" height="40" fill="currentColor" />
    <rect x="85" y="0" width="1" height="40" fill="currentColor" />
    <rect x="88" y="0" width="3" height="40" fill="currentColor" />
    <rect x="93" y="0" width="2" height="40" fill="currentColor" />
    <rect x="97" y="0" width="3" height="40" fill="currentColor" />
  </svg>
);

const MemberDashboard: React.FC = () => {
  const activeDates = [
    new Date(),
    new Date(Date.now() - 86400000),
    new Date(Date.now() - 86400000 * 2),
    new Date(Date.now() - 86400000 * 5),
    new Date(Date.now() - 86400000 * 6),
    new Date(Date.now() - 86400000 * 7),
    new Date(Date.now() - 86400000 * 10),
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl font-black text-white uppercase italic tracking-tighter">
            Champion's <span className="text-[#CCFF00]">Dashboard</span>
          </h1>
          <p className="text-gray-400 font-medium">Welcome back, Alex. Ready to crush today's session?</p>
        </div>
        <div className="flex items-center space-x-3 bg-[#1E1E1E] border border-[#333] px-4 py-2 rounded-xl">
          <Calendar size={20} className="text-[#CCFF00]" />
          <span className="font-bold">{new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Workouts', value: '24', icon: Zap, color: 'text-[#CCFF00]' },
          { label: 'Avg Time', value: '54m', icon: Clock, color: 'text-blue-400' },
          { label: 'Total Volume', value: '18.4k kg', icon: TrendingUp, color: 'text-purple-400' },
          { label: 'Goals Met', value: '4/5', icon: Trophy, color: 'text-orange-400' },
        ].map((stat, i) => (
          <div key={i} className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333] group hover:border-[#CCFF00] transition-colors">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg bg-[#252525] group-hover:scale-110 transition-transform ${stat.color}`}>
                <stat.icon size={24} />
              </div>
            </div>
            <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
            <p className="text-3xl font-black text-white mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Progression Chart */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333]">
            <h3 className="text-xl font-bold mb-6 italic uppercase">Weight Progression <span className="text-xs text-gray-500 font-normal normal-case ml-2">Last 7 Sessions</span></h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weightData}>
                  <defs>
                    <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#CCFF00" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#CCFF00" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="day" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} domain={['dataMin - 5', 'dataMax + 5']} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1E1E1E', border: '1px solid #333', borderRadius: '8px' }}
                    itemStyle={{ color: '#CCFF00' }}
                  />
                  <Area type="monotone" dataKey="weight" stroke="#CCFF00" strokeWidth={3} fillOpacity={1} fill="url(#colorWeight)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <Heatmap data={activeDates} />
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-8">
          {/* Quick Actions */}
          <div className="bg-[#CCFF00] p-6 rounded-2xl shadow-[0_10px_40px_-10px_rgba(204,255,0,0.5)] group overflow-hidden relative">
            <div className="relative z-10">
              <h3 className="text-black text-2xl font-black uppercase italic leading-tight mb-2">Start Training Session</h3>
              <p className="text-black/70 font-bold mb-6">Log your sets, reps, and weights in real-time.</p>
              <button className="flex items-center space-x-2 bg-black text-white px-6 py-3 rounded-xl font-bold hover:translate-x-1 transition-transform">
                <span>Start Workout</span>
                <ArrowRight size={20} />
              </button>
            </div>
            <Dumbbell size={140} className="absolute -right-10 -bottom-10 text-black/10 transform -rotate-12 group-hover:rotate-0 transition-transform duration-500" />
          </div>

          {/* Digital Membership Pass (The Barcode) */}
          <div className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333] group">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold uppercase italic">Member Access</h3>
              <Smartphone size={18} className="text-[#CCFF00]" />
            </div>
            <div className="bg-white p-4 rounded-xl flex flex-col items-center justify-center space-y-3 transition-transform group-hover:scale-[1.02]">
               <p className="text-black font-black uppercase text-[10px] tracking-[0.2em]">AZ Elite Pass</p>
               <BarcodeGraphic className="w-full h-12 text-black" />
               <p className="text-gray-400 font-mono text-[8px]">#0021-X942-ELITE</p>
            </div>
            <p className="text-[10px] text-gray-500 mt-4 text-center font-medium leading-relaxed">
              Scan this code at the gym entrance to automatically log your attendance.
            </p>
            <button className="w-full mt-4 flex items-center justify-center space-x-2 py-2 text-[#CCFF00] bg-[#CCFF00]/5 border border-[#CCFF00]/20 rounded-lg text-xs font-black uppercase tracking-widest hover:bg-[#CCFF00]/10 transition-all">
              <Info size={14} />
              <span>Pass Details</span>
            </button>
          </div>

          {/* Membership Status */}
          <div className="bg-[#1E1E1E] p-6 rounded-2xl border border-[#333]">
            <h3 className="text-lg font-bold mb-4 uppercase italic">Membership</h3>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-400 font-medium">Plan Type</span>
              <span className="text-white font-bold">Yearly Pro Elite</span>
            </div>
            <div className="w-full bg-[#252525] h-2 rounded-full overflow-hidden mb-2">
              <div className="bg-[#CCFF00] h-full" style={{ width: '65%' }}></div>
            </div>
            <div className="flex justify-between text-xs font-bold mb-6">
              <span className="text-gray-500">238 Days Left</span>
              <span className="text-[#CCFF00]">Active</span>
            </div>
            <button className="w-full py-3 border border-[#333] hover:bg-[#252525] rounded-xl font-bold text-sm transition-colors uppercase tracking-widest">
              Manage Subscription
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemberDashboard;
